# demo_launcher
A simple GTK+ based program runner

## Ports
Debian 9 and ubuntu 16.04

## Prerequisites

```
apt-get install build-essential libgtk-3-dev
```

## To Build and Install

```
./bootstrap && make && make install PREFIX=/usr/local/SOMEWHERE
```

